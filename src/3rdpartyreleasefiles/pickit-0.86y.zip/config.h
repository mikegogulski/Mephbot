// pickit.cpp
// by Gayak (170@guyau.qc.ca)
// original program (0.82 and previous) by ackmed@gotwalls.com
#include "item.h"

// defines
#define		CONFIG_UNSET	0xFF

// config struct;
typedef struct Config_t {
	char				Section[128];
	char				Description[128];
	BOOL				Pickup;
	BOOL				Hide;
	ITEMSTRUCT			item;

} CONFIGSTRUCT;
