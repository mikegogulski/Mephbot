// pickit.cpp
// by Gayak (170@guyau.qc.ca)
// original program (0.82 and previous) by ackmed@gotwalls.com
#pragma once
#include "external/D2Hackit.h"
#include "external/D2Client.h"
// defines
#define		VERSION_MAJOR			0
#define		VERSION_MINOR			86

#define		DEBUG_OFF				0
#define		DEBUG_USER				1	// dump minimul for users
#define		DEBUG_DEVEL				2	// dump all debug 
#define		DEBUG_PACKET			3

// global vars
extern DWORD Debug;
extern char DebugBuffer[1024];
extern char ConfigPath[_MAX_PATH];
extern FUNCTIONENTRYPOINTS		*server;

// function definations
BOOL PRIVATE OnCommandDebug(char **argv, int argc);
BOOL PRIVATE OnCommandDumpItems(char** argv, int argc);
BOOL PRIVATE OnCommandRadius(char **argv, int argc);
BOOL PRIVATE OnCommandActivate(char **argv, int argc);
BOOL PRIVATE OnCommandDeactivate(char **argv, int argc);
BOOL PRIVATE OnCommandToggle(char **argv, int argc);
BOOL PRIVATE OnCommandLoad(char** argv, int argc);
BOOL PRIVATE OnCommandGold(char** argv, int argc);
BOOL PRIVATE OnCommandLog(char** argv, int argc);

BOOL LoadConfig(char *file);
DWORD GetDistanceSquared(DWORD x1, DWORD y1, DWORD x2, DWORD y2);

char *ReplaceString(char *source, char *old, char *newtext);